# Spring-boot based banking applicaton

This app shows simple banking application
